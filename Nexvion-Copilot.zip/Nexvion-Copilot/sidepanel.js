// sidepanel.js - Nexvion Co-pilot Client Bridge & WebSocket Gateway

document.addEventListener('DOMContentLoaded', async () => {
  // Navigation Screens
  const privacyGate = document.getElementById('privacy-gate');
  const sessionsHub = document.getElementById('sessions-hub');
  const activeWorkspace = document.getElementById('active-workspace');

  // Screen 1 Elements
  const tabListContainer = document.getElementById('tab-list-container');
  const confirmTabBtn = document.getElementById('confirm-tab-btn');

  // Screen 2 Elements
  const hubTargetBadge = document.getElementById('hub-target-badge');
  const btnCreateChat = document.getElementById('btn-create-chat');
  const sessionListContainer = document.getElementById('session-list-container');
  const switchTabBtn = document.getElementById('switch-tab-btn');

  // Screen 3 Elements
  const btnBackToHub = document.getElementById('btn-back-to-hub');
  const activeChatTitleBadge = document.getElementById('active-chat-title-badge');
  const endSessionBtn = document.getElementById('end-session-btn');
  const chatForm = document.getElementById('chat-form');
  const promptInput = document.getElementById('text-prompt-input');
  const chatLog = document.getElementById('chat-log');
  const submitButton = chatForm.querySelector('.btn-primary');

  // Configuration Constants
  const SERVER_WS_BASE = 'wss://nexvion-brain-server.onrender.com/ws/';
  const STORAGE_KEY = 'nexvion_copilot_sessions';
  const FALLBACK_ICON = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%236B7280"><circle cx="12" cy="12" r="10"/></svg>';

  // State Management
  let selectedTabId = null;
  let selectedTabTitle = '';
  let currentSessionId = null;
  let sessions = [];
  let pendingQuery = null;
  let pendingStepAdvance = false;

  // WebSocket State
  let liveWs = null;
  let isWsConnected = false;

  // --- 1. Storage & Formatting Utilities ---
  async function loadSessions() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY) || localStorage.getItem('live_ai_guide_sessions');
      sessions = stored ? JSON.parse(stored) : [];
    } catch (e) {
      sessions = [];
    }
  }

  function persistSessions() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
  }

  function formatMarkdown(text) {
    if (!text) return '';
    let safe = text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

    safe = safe.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    safe = safe.replace(/\*(.*?)\*/g, '<em>$1</em>');
    safe = safe.replace(/\n/g, '<br>');

    return safe;
  }

  await loadSessions();

  // --- 2. Screen 1: Tab Discovery ---
  async function loadAvailableTabs() {
    tabListContainer.innerHTML = '';
    try {
      const tabs = await chrome.tabs.query({ currentWindow: true });

      tabs.forEach((tab) => {
        const item = document.createElement('div');
        item.className = 'tab-item';

        if (tab.active) {
          item.classList.add('selected');
          selectedTabId = tab.id;
          selectedTabTitle = tab.title || tab.url;
          confirmTabBtn.disabled = false;
        }

        const img = document.createElement('img');
        img.className = 'tab-favicon-img';
        img.src = tab.favIconUrl && tab.favIconUrl.startsWith('http') ? tab.favIconUrl : FALLBACK_ICON;
        img.onerror = () => {
          img.src = FALLBACK_ICON;
        };

        const info = document.createElement('div');
        info.className = 'tab-info';

        const titleText = document.createElement('div');
        titleText.className = 'tab-title-text';
        titleText.textContent = tab.title || 'Untitled Tab';

        const urlText = document.createElement('div');
        urlText.className = 'tab-url-text';
        urlText.textContent = tab.url || '';

        info.appendChild(titleText);
        info.appendChild(urlText);
        item.appendChild(img);
        item.appendChild(info);

        item.addEventListener('click', () => {
          document.querySelectorAll('.tab-item').forEach((el) => el.classList.remove('selected'));
          item.classList.add('selected');
          selectedTabId = tab.id;
          selectedTabTitle = tab.title || tab.url;
          confirmTabBtn.disabled = false;
        });

        tabListContainer.appendChild(item);
      });
    } catch (err) {
      console.error('Tab discovery error:', err);
    }
  }

  await loadAvailableTabs();

  confirmTabBtn.addEventListener('click', () => {
    if (!selectedTabId) return;
    privacyGate.classList.add('hidden');
    sessionsHub.classList.remove('hidden');
    hubTargetBadge.textContent = `🎯 Scoped Tab: ${selectedTabTitle}`;
    renderSessionsList();
  });

  switchTabBtn.addEventListener('click', () => {
    sessionsHub.classList.add('hidden');
    privacyGate.classList.remove('hidden');
    loadAvailableTabs();
  });

  // --- 3. Screen 2: Sessions Management ---
  function renderSessionsList() {
    sessionListContainer.innerHTML = '';

    if (sessions.length === 0) {
      const emptyNotice = document.createElement('div');
      emptyNotice.className = 'empty-sessions-notice';
      emptyNotice.textContent = 'No past conversations found. Start a new session!';
      sessionListContainer.appendChild(emptyNotice);
      return;
    }

    sessions.forEach((session) => {
      const card = document.createElement('div');
      card.className = 'session-card';

      const mainInfo = document.createElement('div');
      mainInfo.className = 'session-main-info';
      mainInfo.addEventListener('click', () => openSession(session.id));

      const title = document.createElement('div');
      title.className = 'session-title-text';
      title.textContent = session.title;

      const meta = document.createElement('div');
      meta.className = 'session-meta-text';
      meta.textContent = `${session.messages.length} messages • ${new Date(session.updatedAt).toLocaleDateString()}`;

      mainInfo.appendChild(title);
      mainInfo.appendChild(meta);

      const actionsDiv = document.createElement('div');
      actionsDiv.className = 'session-actions';

      const renameBtn = document.createElement('button');
      renameBtn.className = 'btn-icon-action';
      renameBtn.innerHTML = '✏️';
      renameBtn.title = 'Rename Chat';
      renameBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const newTitle = prompt('Enter new chat name:', session.title);
        if (newTitle && newTitle.trim() !== '') {
          session.title = newTitle.trim();
          session.updatedAt = new Date().toISOString();
          persistSessions();
          renderSessionsList();
        }
      });

      const deleteBtn = document.createElement('button');
      deleteBtn.className = 'btn-icon-action delete';
      deleteBtn.innerHTML = '🗑️';
      deleteBtn.title = 'Delete Chat';
      deleteBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (confirm(`Are you sure you want to delete "${session.title}"?`)) {
          sessions = sessions.filter((s) => s.id !== session.id);
          persistSessions();
          renderSessionsList();
        }
      });

      actionsDiv.appendChild(renameBtn);
      actionsDiv.appendChild(deleteBtn);

      card.appendChild(mainInfo);
      card.appendChild(actionsDiv);
      sessionListContainer.appendChild(card);
    });
  }

  btnCreateChat.addEventListener('click', () => {
    const newSession = {
      id: 'session_' + Date.now(),
      title: `Guide on ${selectedTabTitle.substring(0, 16)}...`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      messages: []
    };
    sessions.unshift(newSession);
    persistSessions();
    openSession(newSession.id);
  });

  // --- 4. WebSocket Gateway & Server Protocol ---
  function connectWebSocket(sessionId) {
    if (liveWs && (liveWs.readyState === WebSocket.OPEN || liveWs.readyState === WebSocket.CONNECTING)) {
      return;
    }

    liveWs = new WebSocket(SERVER_WS_BASE + sessionId);

    liveWs.onopen = () => {
      isWsConnected = true;
      appendMessageToDOM('system', '🟢 Connected to Nexvion Live Engine.');
    };

    liveWs.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);

        if (msg.error) {
          appendMessageToDOM('system', `⚠️ ${msg.error}`);
        }

        // Only render text if the backend explicitly populated a reply.
        if (msg.reply) {
          appendMessageToDOM('ai', msg.reply);
          saveMessageToCurrentSession('ai', msg.reply);
        }

        if (selectedTabId) {
          if (msg.cursor && msg.cursor.x !== null && msg.cursor.y !== null) {
            chrome.tabs.sendMessage(selectedTabId, {
              action: 'UPDATE_CURSOR',
              payload: {
                x_norm: msg.cursor.x,
                y_norm: msg.cursor.y,
                // Pass the label specifically populated for the tooltip
                text: msg.cursor.label || 'Target',
                step_index: msg.step_index
              }
            }).catch(() => {});
          } else {
            chrome.tabs.sendMessage(selectedTabId, {
              action: 'CLEAR_CURSOR'
            }).catch(() => {});
          }

          if (msg.completed) {
            chrome.tabs.sendMessage(selectedTabId, {
              action: 'CLEAR_CURSOR'
            }).catch(() => {});
          }
        }
      } catch (err) {
        console.error('Error parsing server payload:', err);
      } finally {
        submitButton.disabled = false;
        promptInput.disabled = false;
        promptInput.focus();
      }
    };

    liveWs.onclose = () => {
      isWsConnected = false;
      appendMessageToDOM('system', '🔴 Disconnected from Nexvion\'s Live Server.');
    };

    liveWs.onerror = (err) => {
      console.error('WebSocket connection error:', err);
      submitButton.disabled = false;
      promptInput.disabled = false;
    };
  }

  // --- 5. Frame Capture Pipeline & Runtime Message Router ---
  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === 'FRAME_CAPTURED') {
      const b64Data = message.dataUrl ? message.dataUrl.split(',')[1] : null;

      if (isWsConnected && liveWs && liveWs.readyState === WebSocket.OPEN) {
        if (pendingQuery !== null) {
          liveWs.send(JSON.stringify({
            type: 'turn',
            text: pendingQuery,
            frame_b64: b64Data
          }));
          pendingQuery = null;
        } else if (pendingStepAdvance) {
          liveWs.send(JSON.stringify({
            type: 'step_complete',
            frame_b64: b64Data
          }));
          pendingStepAdvance = false;
        }
      }
    }

    if (message.action === 'STEP_COMPLETED') {
      if (isWsConnected && liveWs && liveWs.readyState === WebSocket.OPEN) {
        pendingStepAdvance = true;
        chrome.runtime.sendMessage({ action: 'REQUEST_FRAME' });
      }
    }
  });

  // --- 6. Screen 3 Lifecycle ---
  async function openSession(sessionId) {
    currentSessionId = sessionId;
    const session = sessions.find((s) => s.id === sessionId);
    if (!session) return;

    if (selectedTabId) {
      await chrome.tabs.update(selectedTabId, { active: true });
    }

    sessionsHub.classList.add('hidden');
    activeWorkspace.classList.remove('hidden');
    activeChatTitleBadge.innerHTML = `<span>🟢</span> ${session.title.substring(0, 14)}...`;

    chatLog.innerHTML = '';
    if (session.messages.length === 0) {
      appendMessageToDOM('system', 'Ask a question or request navigation guidance on this page.');
    } else {
      session.messages.forEach((msg) => appendMessageToDOM(msg.role, msg.content));
    }

    connectWebSocket(sessionId);
  }

  btnBackToHub.addEventListener('click', teardownSession);
  endSessionBtn.addEventListener('click', teardownSession);

  function teardownSession() {
    if (liveWs) {
      liveWs.close();
      liveWs = null;
      isWsConnected = false;
    }
    if (selectedTabId) {
      chrome.tabs.sendMessage(selectedTabId, { action: 'CLEAR_CURSOR' }).catch(() => {});
    }
    activeWorkspace.classList.add('hidden');
    sessionsHub.classList.remove('hidden');
    renderSessionsList();
  }

  // --- 7. Messaging Submission Utilities ---
  function appendMessageToDOM(role, content) {
    const msgDiv = document.createElement('div');
    msgDiv.className = `chat-msg ${role}`;
    if (role === 'system') {
      msgDiv.textContent = content;
    } else {
      msgDiv.innerHTML = formatMarkdown(content);
    }
    chatLog.appendChild(msgDiv);
    chatLog.scrollTop = chatLog.scrollHeight;
  }

  function saveMessageToCurrentSession(role, content) {
    const session = sessions.find((s) => s.id === currentSessionId);
    if (session) {
      session.messages.push({ role, content, timestamp: new Date().toISOString() });
      session.updatedAt = new Date().toISOString();
      persistSessions();
    }
  }

  chatForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const query = promptInput.value.trim();
    if (!query) return;

    if (!isWsConnected || !liveWs || liveWs.readyState !== WebSocket.OPEN) {
      appendMessageToDOM('system', '🔴 Disconnected from Nexvion\'s Live Server.');
      if (currentSessionId) {
        connectWebSocket(currentSessionId);
      }
      return;
    }

    appendMessageToDOM('user', query);
    saveMessageToCurrentSession('user', query);

    pendingQuery = query;
    promptInput.value = '';
    promptInput.disabled = true;
    submitButton.disabled = true;

    chrome.runtime.sendMessage({ action: 'REQUEST_FRAME' });
  });
});
// sidepanel.js - Live AI Screen Guide Client Bridge (Stage 2 Integration)

document.addEventListener('DOMContentLoaded', async () => {
  // Navigation Screens
  const privacyGate = document.getElementById('privacy-gate');
  const sessionsHub = document.getElementById('sessions-hub');
  const activeWorkspace = document.getElementById('active-workspace');

  // Screen 1 Elements
  const tabListContainer = document.getElementById('tab-list-container');
  const confirmTabBtn = document.getElementById('confirm-tab-btn');
  const micPermBanner = document.getElementById('mic-perm-banner');

  // Screen 2 Elements
  const hubTargetBadge = document.getElementById('hub-target-badge');
  const btnCreateChat = document.getElementById('btn-create-chat');
  const sessionListContainer = document.getElementById('session-list-container');
  const switchTabBtn = document.getElementById('switch-tab-btn');

  // Screen 3 Elements
  const btnBackToHub = document.getElementById('btn-back-to-hub');
  const activeChatTitleBadge = document.getElementById('active-chat-title-badge');
  const endSessionBtn = document.getElementById('end-session-btn');
  const chatForm = document.getElementById('chat-form');
  const promptInput = document.getElementById('text-prompt-input');
  const chatLog = document.getElementById('chat-log');
  const submitButton = chatForm.querySelector('.btn-primary');
  
  // Audio UI
  const micToggleBtn = document.getElementById('mic-toggle-btn');
  const speakerToggleBtn = document.getElementById('speaker-toggle-btn');
  const canvas = document.getElementById('audio-visualizer');
  const canvasCtx = canvas.getContext('2d');

  // Configuration Constants
  const SERVER_WS_BASE = "ws://127.0.0.1:8000/ws/";
  const NUM_BARS = 30;
  const FALLBACK_ICON = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%236B7280"><circle cx="12" cy="12" r="10"/></svg>';

  // State Management
  let selectedTabId = null;
  let selectedTabTitle = "";
  let currentSessionId = null;
  let sessions = [];
  let pendingQuery = null; // Holds the text while frame is capturing

  // WebSocket State
  let liveWs = null;
  let isWsConnected = false;

  // Audio Visualizer Idle State
  let visualizerIntervalId = null;

  // --- 1. Storage Utilities ---
  async function loadSessions() {
    try {
      const stored = localStorage.getItem('live_ai_guide_sessions');
      sessions = stored ? JSON.parse(stored) : [];
    } catch (e) {
      sessions = [];
    }
  }

  function persistSessions() {
    localStorage.setItem('live_ai_guide_sessions', JSON.stringify(sessions));
  }

  await loadSessions();

  // --- 2. Screen 1: Tab Discovery ---
  if (micPermBanner) micPermBanner.style.display = 'none';

  async function loadAvailableTabs() {
    tabListContainer.innerHTML = '';
    try {
      const tabs = await chrome.tabs.query({ currentWindow: true });
      
      tabs.forEach((tab) => {
        const item = document.createElement('div');
        item.className = 'tab-item';
        
        if (tab.active) {
          item.classList.add('selected');
          selectedTabId = tab.id;
          selectedTabTitle = tab.title || tab.url;
          confirmTabBtn.disabled = false;
        }

        const img = document.createElement('img');
        img.className = 'tab-favicon-img';
        img.src = tab.favIconUrl && tab.favIconUrl.startsWith('http') ? tab.favIconUrl : FALLBACK_ICON;
        img.onerror = () => { img.src = FALLBACK_ICON; };

        const info = document.createElement('div');
        info.className = 'tab-info';
        
        const titleText = document.createElement('div');
        titleText.className = 'tab-title-text';
        titleText.textContent = tab.title || "Untitled Tab";

        const urlText = document.createElement('div');
        urlText.className = 'tab-url-text';
        urlText.textContent = tab.url || "";

        info.appendChild(titleText);
        info.appendChild(urlText);
        item.appendChild(img);
        item.appendChild(info);

        item.addEventListener('click', () => {
          document.querySelectorAll('.tab-item').forEach(el => el.classList.remove('selected'));
          item.classList.add('selected');
          selectedTabId = tab.id;
          selectedTabTitle = tab.title || tab.url;
          confirmTabBtn.disabled = false;
        });

        tabListContainer.appendChild(item);
      });
    } catch (err) {
      console.error("Tab discovery error:", err);
    }
  }

  await loadAvailableTabs();

  confirmTabBtn.addEventListener('click', () => {
    if (!selectedTabId) return;
    privacyGate.classList.add('hidden');
    sessionsHub.classList.remove('hidden');
    hubTargetBadge.textContent = `🎯 Scoped Tab: ${selectedTabTitle}`;
    renderSessionsList();
  });

  switchTabBtn.addEventListener('click', () => {
    sessionsHub.classList.add('hidden');
    privacyGate.classList.remove('hidden');
    loadAvailableTabs();
  });

  // --- 3. Screen 2: Sessions Management ---
  function renderSessionsList() {
    sessionListContainer.innerHTML = '';

    if (sessions.length === 0) {
      const emptyNotice = document.createElement('div');
      emptyNotice.className = 'empty-sessions-notice';
      emptyNotice.textContent = 'No past conversations found. Start a new session!';
      sessionListContainer.appendChild(emptyNotice);
      return;
    }

    sessions.forEach((session) => {
      const card = document.createElement('div');
      card.className = 'session-card';

      const mainInfo = document.createElement('div');
      mainInfo.className = 'session-main-info';
      mainInfo.addEventListener('click', () => openSession(session.id));

      const title = document.createElement('div');
      title.className = 'session-title-text';
      title.textContent = session.title;

      const meta = document.createElement('div');
      meta.className = 'session-meta-text';
      meta.textContent = `${session.messages.length} messages • ${new Date(session.updatedAt).toLocaleDateString()}`;

      mainInfo.appendChild(title);
      mainInfo.appendChild(meta);
      card.appendChild(mainInfo);
      sessionListContainer.appendChild(card);
    });
  }

  btnCreateChat.addEventListener('click', () => {
    const newSession = {
      id: 'session_' + Date.now(),
      title: `Guide on ${selectedTabTitle.substring(0, 16)}...`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      messages: []
    };
    sessions.unshift(newSession);
    persistSessions();
    openSession(newSession.id);
  });

  // --- 4. WebSocket Gateway & Server Payload Logic ---
  function connectWebSocket(sessionId) {
    if (liveWs && (liveWs.readyState === WebSocket.OPEN || liveWs.readyState === WebSocket.CONNECTING)) {
      return;
    }

    // Connect to dynamic session endpoint
    liveWs = new WebSocket(SERVER_WS_BASE + sessionId);

    liveWs.onopen = () => {
      isWsConnected = true;
      appendMessageToDOM('system', '🟢 Connected to Live AI Guide engine.');
    };

    liveWs.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        
        if (msg.error) {
          appendMessageToDOM('system', `⚠️ Error: ${msg.error}`);
        } else if (msg.reply) {
          appendMessageToDOM('ai', msg.reply);
          saveMessageToCurrentSession('ai', msg.reply);
        }
      } catch (err) {
        console.error("Error parsing server message:", err);
      } finally {
        submitButton.disabled = false;
        promptInput.disabled = false;
        promptInput.focus();
      }
    };

    liveWs.onclose = () => {
      isWsConnected = false;
      appendMessageToDOM('system', '🔴 Disconnected from Live Guide server.');
    };

    liveWs.onerror = () => {
      appendMessageToDOM('system', '⚠️ Connection failed. Verify brain-server is running.');
      submitButton.disabled = false;
      promptInput.disabled = false;
    };
  }

  // --- 5. Frame Capture Pipeline Listener ---
  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === 'FRAME_CAPTURED' && pendingQuery) {
      // Strip out the data URL prefix so the Brain Server gets pure base64
      const b64Data = message.dataUrl.split(',')[1];
      
      if (isWsConnected && liveWs) {
        liveWs.send(JSON.stringify({
          text: pendingQuery,
          needs_screenshot: true,
          frame_b64: b64Data
        }));
        appendMessageToDOM('system', '📷 Frame captured and routed to OpenRouter Vision.');
      }
      pendingQuery = null;
    }
  });

  // --- 6. Screen 3 Lifecycle ---
  async function openSession(sessionId) {
    currentSessionId = sessionId;
    const session = sessions.find(s => s.id === sessionId);
    if (!session) return;

    await chrome.tabs.update(selectedTabId, { active: true });

    sessionsHub.classList.add('hidden');
    activeWorkspace.classList.remove('hidden');
    activeChatTitleBadge.innerHTML = `<span>🟢</span> ${session.title.substring(0, 14)}...`;

    chatLog.innerHTML = '';
    if (session.messages.length === 0) {
      appendMessageToDOM('system', 'Chatbot active. Type your question or ask what to click.');
    } else {
      session.messages.forEach(msg => appendMessageToDOM(msg.role, msg.content));
    }

    connectWebSocket(sessionId);
    startIdleVisualizer();
  }

  btnBackToHub.addEventListener('click', teardownSession);
  endSessionBtn.addEventListener('click', teardownSession);

  function teardownSession() {
    if (liveWs) {
      liveWs.close();
      liveWs = null;
      isWsConnected = false;
    }
    if (visualizerIntervalId) {
      clearInterval(visualizerIntervalId);
      visualizerIntervalId = null;
    }
    activeWorkspace.classList.add('hidden');
    sessionsHub.classList.remove('hidden');
    renderSessionsList();
  }

  // --- 7. Chat Messaging Utilities ---
  function appendMessageToDOM(role, content) {
    const msgDiv = document.createElement('div');
    msgDiv.className = `chat-msg ${role}`;
    msgDiv.textContent = content;
    chatLog.appendChild(msgDiv);
    chatLog.scrollTop = chatLog.scrollHeight;
  }

  function saveMessageToCurrentSession(role, content) {
    const session = sessions.find(s => s.id === currentSessionId);
    if (session) {
      session.messages.push({ role, content, timestamp: new Date().toISOString() });
      session.updatedAt = new Date().toISOString();
      persistSessions();
    }
  }

  chatForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const query = promptInput.value.trim();
    if (!query) return;

    appendMessageToDOM('user', query);
    saveMessageToCurrentSession('user', query);
    
    pendingQuery = query;
    promptInput.value = '';
    promptInput.disabled = true;
    submitButton.disabled = true;

    if (isWsConnected && liveWs && liveWs.readyState === WebSocket.OPEN) {
      // Trigger the background service worker to fetch the tab surface
      chrome.runtime.sendMessage({ action: 'REQUEST_FRAME' });
    } else {
      appendMessageToDOM('system', '⚠️ WebSocket disconnected.');
      submitButton.disabled = false;
      promptInput.disabled = false;
    }
  });

  // --- 8. Visualizer (Idle) ---
  function startIdleVisualizer() {
    canvas.width = canvas.parentElement.clientWidth || 300;
    canvas.height = canvas.parentElement.clientHeight || 42;
    if (visualizerIntervalId) clearInterval(visualizerIntervalId);
    visualizerIntervalId = setInterval(drawIdleBars, 1000);
  }

  function drawIdleBars() {
    canvasCtx.fillStyle = '#0f172a';
    canvasCtx.fillRect(0, 0, canvas.width, canvas.height);
    const spacing = 3;
    const barWidth = Math.max(2, (canvas.width - spacing * (NUM_BARS + 1)) / NUM_BARS);
    for (let i = 0; i < NUM_BARS; i++) {
      const x = spacing + i * (barWidth + spacing);
      const y = (canvas.height - 4) / 2;
      canvasCtx.fillStyle = '#334155';
      canvasCtx.beginPath();
      canvasCtx.roundRect ? canvasCtx.roundRect(x, y, barWidth, 4, 2) : canvasCtx.rect(x, y, barWidth, 4);
      canvasCtx.fill();
    }
  }
});
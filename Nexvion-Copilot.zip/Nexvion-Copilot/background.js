// background.js - Service Worker Orchestrator (Stage 2 Integration)

// 1. Configure default side panel opening behavior on action click
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error("Side panel configuration error:", error));

// 2. Offscreen Document Management
let creatingOffscreen;

async function setupOffscreenDocument(path) {
  // Check if offscreen document already exists
  const hasDocument = await chrome.offscreen.hasDocument();
  if (hasDocument) return;

  // Prevent concurrent creation
  if (creatingOffscreen) {
    await creatingOffscreen;
  } else {
    creatingOffscreen = chrome.offscreen.createDocument({
      url: path,
      reasons: [chrome.offscreen.Reason.DOM_PARSER],
      justification: 'Process and downsample tab captures for AI processing'
    });
    await creatingOffscreen;
    creatingOffscreen = null;
  }
}

// 3. Runtime Message Router (Tab Capture Pipeline)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'REQUEST_FRAME') {
    (async () => {
      try {
        // Ensure the offscreen downsampler is alive
        await setupOffscreenDocument('offscreen.html');
        
        // Capture the raw visible tab surface (requires activeTab or tabCapture permission)
        const rawDataUrl = await chrome.tabs.captureVisibleTab(null, { format: 'png' });
        
        // Pipe to offscreen document for 1024x576 JPEG downsampling
        chrome.runtime.sendMessage({
          action: 'OFFSCREEN_PROCESS_FRAME',
          dataUrl: rawDataUrl
        });
        
        sendResponse({ status: "processing" });
      } catch (err) {
        console.error("Tab capture failed:", err);
        sendResponse({ status: "error", error: err.toString() });
      }
    })();
    return true; // Keep message channel open for asynchronous response
  }
});
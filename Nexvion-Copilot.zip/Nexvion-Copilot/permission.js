// permission.js

document.getElementById('grant-mic-btn').addEventListener('click', async () => {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach(track => track.stop());
    
    chrome.runtime.sendMessage({ action: 'MIC_PERMISSION_GRANTED' });
    
    document.querySelector('.card').innerHTML = `
      <h2 style="color: #059669;">✅ Microphone Enabled!</h2>
      <p>Permission granted successfully. You can close this tab and return to your guide.</p>
    `;
    setTimeout(() => window.close(), 1200);
  } catch (err) {
    alert("Permission was dismissed or blocked. Please allow microphone access in your browser settings.");
  }
});
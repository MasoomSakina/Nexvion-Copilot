// content_script.js

// 1. Setup Isolated Shadow DOM
const host = document.createElement('div');
host.id = 'live-ai-guide-root';
host.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; pointer-events: none !important; z-index: 2147483647;';
document.body.appendChild(host);

const shadow = host.attachShadow({ mode: 'open' });

// 2. Inject Overlay Styles
const style = document.createElement('style');
style.textContent = `
  :host {
    pointer-events: none !important;
  }
  
  #ghost-cursor {
    position: fixed;
    top: 0;
    left: 0;
    pointer-events: none !important;
    z-index: 2147483647;
    transition: transform 300ms cubic-bezier(0.2, 0.8, 0.2, 1);
    transform: translate3d(-100px, -100px, 0); 
  }
  
  .pointer-arrow {
    width: 24px;
    height: 24px;
    fill: #3B82F6; 
    filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
  }

  .tooltip-bubble {
    background: #1f2937;
    color: white;
    padding: 4px 8px;
    border-radius: 4px;
    font-family: -apple-system, sans-serif;
    font-size: 12px;
    margin-top: 4px;
    display: inline-block;
    white-space: nowrap;
  }
  
  #target-highlight-box {
    position: fixed;
    border: 2px solid #3B82F6;
    background-color: rgba(59, 130, 246, 0.12);
    border-radius: 6px;
    box-shadow: 0 0 15px rgba(59, 130, 246, 0.5);
    pointer-events: none !important;
    transition: all 250ms ease-out;
    opacity: 0;
    top: 0; left: 0; width: 0; height: 0;
  }
`;
shadow.appendChild(style);

// 3. Build Overlay Elements
const cursor = document.createElement('div');
cursor.id = 'ghost-cursor';
cursor.innerHTML = `
  <svg class="pointer-arrow" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M5.5 3.21V20.8c0 .45.54.67.85.35l4.86-4.86a.5.5 0 0 1 .35-.15h6.84c.45 0 .67-.54.35-.85L5.5 3.21z"/>
  </svg>
  <div class="tooltip-bubble" id="cursor-tooltip">Guide Active</div>
`;
shadow.appendChild(cursor);

const highlightBox = document.createElement('div');
highlightBox.id = 'target-highlight-box';
shadow.appendChild(highlightBox);

// 4. Coordinate Translation Engine
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'UPDATE_CURSOR') {
    const { x_norm, y_norm, text } = message.payload;
    const pixelX = (x_norm / 1000) * window.innerWidth;
    const pixelY = (y_norm / 1000) * window.innerHeight;
    
    cursor.style.transform = `translate3d(${pixelX}px, ${pixelY}px, 0)`;
    
    const tooltip = shadow.getElementById('cursor-tooltip');
    if (text) {
      tooltip.textContent = text;
      tooltip.style.display = 'inline-block';
    } else {
      tooltip.style.display = 'none';
    }
  }
  
  if (message.action === 'HIGHLIGHT_ELEMENT') {
    const { x_norm, y_norm, width_norm, height_norm } = message.payload;
    const pixelX = (x_norm / 1000) * window.innerWidth;
    const pixelY = (y_norm / 1000) * window.innerHeight;
    const pixelWidth = (width_norm / 1000) * window.innerWidth;
    const pixelHeight = (height_norm / 1000) * window.innerHeight;
    
    highlightBox.style.left = `${pixelX}px`;
    highlightBox.style.top = `${pixelY}px`;
    highlightBox.style.width = `${pixelWidth}px`;
    highlightBox.style.height = `${pixelHeight}px`;
    highlightBox.style.opacity = '1';
  }
  
  if (message.action === 'CLEAR_HIGHLIGHT') {
     highlightBox.style.opacity = '0';
  }
});
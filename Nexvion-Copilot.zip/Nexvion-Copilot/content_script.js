// content_script.js - Live Spatial DOM Anchoring & Zero-LLM Step Completion Monitor

(function () {
  // Prevent duplicate script injection
  if (window.__LIVE_AI_GUIDE_INJECTED__) return;
  window.__LIVE_AI_GUIDE_INJECTED__ = true;

  // 1. Setup Isolated Shadow DOM
  let host = document.getElementById('live-ai-guide-root');
  if (!host) {
    host = document.createElement('div');
    host.id = 'live-ai-guide-root';
    host.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; pointer-events: none !important; z-index: 2147483647;';
    document.documentElement.appendChild(host);
  }

  const shadow = host.attachShadow({ mode: 'open' });

  // 2. Inject Aggressive Overlay Styles
  const style = document.createElement('style');
  style.textContent = `
    :host {
      pointer-events: none !important;
    }

    #ghost-cursor {
      position: fixed;
      top: 0;
      left: 0;
      pointer-events: none !important;
      z-index: 2147483647;
      transition: transform 180ms cubic-bezier(0.2, 0.8, 0.2, 1);
      transform: translate3d(-200px, -200px, 0);
      will-change: transform;
      display: none;
      filter: drop-shadow(0 8px 16px rgba(0, 0, 0, 0.5));
    }

    .pointer-arrow {
      width: 48px;
      height: 48px;
      fill: #ef4444; /* High visibility red */
      stroke: #ffffff;
      stroke-width: 1px;
      animation: pointer-bounce 1s infinite alternate;
    }

    @keyframes pointer-bounce {
      0% { transform: translate(0, 0); }
      100% { transform: translate(-10px, -10px); }
    }

    .tooltip-bubble {
      background: #2563eb; /* Strong blue background */
      color: #ffffff;
      padding: 10px 14px;
      border-radius: 8px;
      border: 2px solid #ffffff;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-size: 15px;
      font-weight: 700;
      margin-top: 8px;
      display: inline-block;
      white-space: nowrap;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.3);
    }

    #target-highlight-box {
      position: fixed;
      border: 3px solid #ef4444; /* Red box to match pointer */
      background-color: rgba(239, 68, 68, 0.15);
      border-radius: 6px;
      box-shadow: 0 0 24px rgba(239, 68, 68, 0.5);
      pointer-events: none !important;
      transition: all 180ms ease-out;
      opacity: 0;
      top: 0;
      left: 0;
      width: 0;
      height: 0;
      will-change: top, left, width, height, opacity;
    }
  `;
  shadow.appendChild(style);

  // 3. Build Overlay Elements
  const cursor = document.createElement('div');
  cursor.id = 'ghost-cursor';
  cursor.innerHTML = `
    <svg class="pointer-arrow" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
      <path d="M5.5 3.21V20.8c0 .45.54.67.85.35l4.86-4.86a.5.5 0 0 1 .35-.15h6.84c.45 0 .67-.54.35-.85L5.5 3.21z"/>
    </svg>
    <div class="tooltip-bubble" id="cursor-tooltip">Target</div>
  `;
  shadow.appendChild(cursor);

  const highlightBox = document.createElement('div');
  highlightBox.id = 'target-highlight-box';
  shadow.appendChild(highlightBox);

  const tooltip = shadow.getElementById('cursor-tooltip');

  // 4. Live DOM Anchor State
  let activeAnchoredElement = null;
  let activeCompletionHandler = null;
  let activeCompletionEventType = null;
  let activeStepIndex = null;
  let layoutObserver = null;
  let rafPositionId = null;

  function updateOverlayPosition() {
    if (!activeAnchoredElement) return;

    if (!document.documentElement.contains(activeAnchoredElement)) {
      return;
    }

    const rect = activeAnchoredElement.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return;

    highlightBox.style.left = `${rect.left}px`;
    highlightBox.style.top = `${rect.top}px`;
    highlightBox.style.width = `${rect.width}px`;
    highlightBox.style.height = `${rect.height}px`;
    highlightBox.style.opacity = '1';

    const targetX = rect.left + rect.width / 2;
    const targetY = rect.top + rect.height / 2;
    cursor.style.transform = `translate3d(${targetX}px, ${targetY}px, 0)`;
    cursor.style.display = 'block';
  }

  function schedulePositionUpdate() {
    if (rafPositionId) cancelAnimationFrame(rafPositionId);
    rafPositionId = requestAnimationFrame(updateOverlayPosition);
  }

  function clearActiveAnchor() {
    if (activeAnchoredElement && activeCompletionHandler && activeCompletionEventType) {
      activeAnchoredElement.removeEventListener(activeCompletionEventType, activeCompletionHandler, { capture: true });
    }
    if (layoutObserver) {
      layoutObserver.disconnect();
      layoutObserver = null;
    }
    activeAnchoredElement = null;
    activeCompletionHandler = null;
    activeCompletionEventType = null;
    activeStepIndex = null;

    cursor.style.display = 'none';
    cursor.style.transform = 'translate3d(-200px, -200px, 0)';
    highlightBox.style.opacity = '0';
    highlightBox.style.width = '0px';
    highlightBox.style.height = '0px';
  }

  function attachCompletionListener(element, stepIndex) {
    const tagName = element.tagName.toLowerCase();
    const isInput = tagName === 'input' || tagName === 'textarea' || tagName === 'select';

    activeCompletionEventType = isInput ? 'blur' : 'click';
    activeStepIndex = stepIndex;

    activeCompletionHandler = () => {
      if (isInput && tagName === 'input' && element.type !== 'checkbox' && element.type !== 'radio') {
        if (!element.value || element.value.trim() === '') {
          return; 
        }
      }

      chrome.runtime.sendMessage({
        action: 'STEP_COMPLETED',
        step_index: stepIndex
      }).catch(() => {});

      clearActiveAnchor();
    };

    element.addEventListener(activeCompletionEventType, activeCompletionHandler, { once: true, capture: true });
  }

  function anchorToCoordinates(xNorm, yNorm, labelText, stepIndex) {
    clearActiveAnchor();

    const clientX = (xNorm / 1000) * window.innerWidth;
    const clientY = (yNorm / 1000) * window.innerHeight;

    let target = document.elementFromPoint(clientX, clientY);

    if (!target) {
      cursor.style.transform = `translate3d(${clientX}px, ${clientY}px, 0)`;
      cursor.style.display = 'block';
      tooltip.textContent = labelText || 'Click here';
      return;
    }

    const interactiveTarget = target.closest('button, a, input, select, textarea, [role="button"], [tabindex]') || target;
    activeAnchoredElement = interactiveTarget;

    tooltip.textContent = labelText || 'Click here';
    updateOverlayPosition();

    attachCompletionListener(activeAnchoredElement, stepIndex);

    layoutObserver = new MutationObserver(() => {
      schedulePositionUpdate();
    });
    layoutObserver.observe(document.body, { attributes: true, childList: true, subtree: true });
  }

  // 5. Scroll & Resize Matrix Synchronization
  window.addEventListener('scroll', schedulePositionUpdate, { passive: true });
  window.addEventListener('resize', schedulePositionUpdate, { passive: true });

  // 6. Chrome Runtime Message Listener
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'UPDATE_CURSOR') {
      const { x_norm, y_norm, text, step_index } = message.payload;
      anchorToCoordinates(x_norm, y_norm, text, step_index);
      sendResponse({ status: 'anchored' });
    }

    if (message.action === 'CLEAR_CURSOR') {
      clearActiveAnchor();
      sendResponse({ status: 'cleared' });
    }
  });
})();
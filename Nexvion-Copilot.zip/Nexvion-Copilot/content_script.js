// content_script.js - Nexvion Silent Spatial Grounding & Ghost Cursor Engine

(() => {
  if (window.__NEXVION_INJECTED__) return;
  window.__NEXVION_INJECTED__ = true;

  // Root Overlay Container for Ghost Cursor Only
  let guideRoot = document.getElementById('live-ai-guide-root');
  if (!guideRoot) {
    guideRoot = document.createElement('div');
    guideRoot.id = 'live-ai-guide-root';
    guideRoot.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      z-index: 2147483647;
      pointer-events: none !important;
      overflow: hidden;
    `;
    document.documentElement.appendChild(guideRoot);
  }

  // --- 1. Silent Spatial Geometry Extraction ---
  const INTERACTIVE_SELECTORS = [
    'button',
    'a[href]',
    'input',
    'select',
    'textarea',
    '[role="button"]',
    '[role="link"]',
    '[role="searchbox"]',
    '[role="tab"]',
    '[role="menuitem"]',
    '[contenteditable="true"]',
    'yt-formatted-string',
    'ytd-thumbnail',
    '#search-icon-legacy',
    '#search-input'
  ];

  function isElementVisible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    if (
      style.display === 'none' ||
      style.visibility === 'hidden' ||
      style.opacity === '0' ||
      parseFloat(style.opacity) < 0.1
    ) {
      return false;
    }
    const rect = el.getBoundingClientRect();
    if (rect.width <= 4 || rect.height <= 4) return false;
    if (
      rect.bottom < 0 ||
      rect.right < 0 ||
      rect.top > window.innerHeight ||
      rect.left > window.innerWidth
    ) {
      return false;
    }
    return true;
  }

  function collectVisibleInteractiveElements() {
    const candidates = Array.from(document.querySelectorAll(INTERACTIVE_SELECTORS.join(',')));
    const uniqueElements = [];
    const seenRects = new Set();

    for (const el of candidates) {
      if (!isElementVisible(el)) continue;

      const rect = el.getBoundingClientRect();
      const key = `${Math.round(rect.top)}_${Math.round(rect.left)}_${Math.round(rect.width)}_${Math.round(rect.height)}`;
      if (seenRects.has(key)) continue;
      seenRects.add(key);

      uniqueElements.push(el);
      if (uniqueElements.length >= 60) break; // Viewport limit for precision
    }

    return uniqueElements;
  }

  function generateSilentMarkerMap() {
    const elements = collectVisibleInteractiveElements();
    const markerMap = {};

    elements.forEach((el, index) => {
      const tagId = index + 1;
      const rect = el.getBoundingClientRect();

      // Normalized coordinates on [0, 1000] scale for resolution independence
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      const normX = Math.round((centerX / window.innerWidth) * 1000);
      const normY = Math.round((centerY / window.innerHeight) * 1000);

      // Normalized bounding box dimensions
      const normBox = {
        left: Math.round((rect.left / window.innerWidth) * 1000),
        top: Math.round((rect.top / window.innerHeight) * 1000),
        right: Math.round((rect.right / window.innerWidth) * 1000),
        bottom: Math.round((rect.bottom / window.innerHeight) * 1000)
      };

      const labelText = (
        el.getAttribute('aria-label') ||
        el.innerText ||
        el.getAttribute('placeholder') ||
        el.getAttribute('title') ||
        el.tagName.toLowerCase()
      ).substring(0, 40).replace(/[\n\r]+/g, ' ').trim();

      markerMap[tagId] = {
        id: tagId,
        x: normX,
        y: normY,
        box: normBox,
        pixel_x: Math.round(centerX),
        pixel_y: Math.round(centerY),
        tag_name: el.tagName.toLowerCase(),
        label: labelText
      };
    });

    return markerMap;
  }

  // --- 2. Ghost Cursor & Pulse Overlay ---
  let cursorElement = null;

  function updateCursor(xNorm, yNorm, instructionText, stepIndex) {
    clearCursor();

    const pixelX = (xNorm / 1000) * window.innerWidth;
    const pixelY = (yNorm / 1000) * window.innerHeight;

    cursorElement = document.createElement('div');
    cursorElement.id = 'nexvion-ghost-cursor';
    cursorElement.style.cssText = `
      position: fixed;
      top: ${pixelY}px;
      left: ${pixelX}px;
      transform: translate(-50%, -50%);
      display: flex;
      flex-direction: column;
      align-items: center;
      pointer-events: none !important;
      z-index: 2147483647;
      transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
    `;

    const targetRing = document.createElement('div');
    targetRing.style.cssText = `
      width: 44px;
      height: 44px;
      border: 3px solid #3B82F6;
      border-radius: 50%;
      background: rgba(59, 130, 246, 0.2);
      box-shadow: 0 0 14px rgba(59, 130, 246, 0.8), inset 0 0 8px rgba(59, 130, 246, 0.5);
      animation: nexvion-pulse 1.4s infinite alternate;
    `;

    const cursorPointer = document.createElement('div');
    cursorPointer.style.cssText = `
      position: absolute;
      top: 50%;
      left: 50%;
      width: 12px;
      height: 12px;
      background: #FFFFFF;
      border: 2px solid #1D4ED8;
      border-radius: 50%;
      transform: translate(-50%, -50%);
    `;

    const tooltip = document.createElement('div');
    tooltip.style.cssText = `
      margin-top: 10px;
      background: #111827;
      color: #F9FAFB;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-size: 13px;
      font-weight: 600;
      padding: 6px 12px;
      border-radius: 6px;
      border: 1px solid #374151;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.5);
      white-space: nowrap;
      pointer-events: none !important;
    `;
    tooltip.textContent = instructionText || 'Click here';

    cursorElement.appendChild(targetRing);
    cursorElement.appendChild(cursorPointer);
    cursorElement.appendChild(tooltip);

    guideRoot.appendChild(cursorElement);
  }

  function clearCursor() {
    if (cursorElement) {
      cursorElement.remove();
      cursorElement = null;
    }
  }

  // Keyframe Pulse Animation Injector
  if (!document.getElementById('nexvion-guide-styles')) {
    const styleTag = document.createElement('style');
    styleTag.id = 'nexvion-guide-styles';
    styleTag.textContent = `
      @keyframes nexvion-pulse {
        0% { transform: scale(0.9); opacity: 0.7; }
        100% { transform: scale(1.15); opacity: 1; }
      }
    `;
    document.head.appendChild(styleTag);
  }

  // --- 3. Chrome Runtime Message Dispatcher ---
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'DRAW_TAGS') {
      const markerMap = generateSilentMarkerMap();
      sendResponse({ success: true, marker_map: markerMap });
      return true;
    }

    if (message.action === 'CLEAR_TAGS') {
      sendResponse({ success: true });
      return true;
    }

    if (message.action === 'UPDATE_CURSOR') {
      const p = message.payload;
      updateCursor(p.x_norm, p.y_norm, p.text, p.step_index);
      sendResponse({ success: true });
      return true;
    }

    if (message.action === 'CLEAR_CURSOR') {
      clearCursor();
      sendResponse({ success: true });
      return true;
    }
  });
})();
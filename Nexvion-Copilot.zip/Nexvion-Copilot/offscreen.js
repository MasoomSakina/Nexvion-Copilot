// offscreen.js - 1 FPS Viewport Frame Downsampler

let canvasElement = null;
let canvasContext = null;

const TARGET_WIDTH = 1024;
const TARGET_HEIGHT = 576;
const JPEG_QUALITY = 0.55; // Balances token payload size and visual clarity

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'OFFSCREEN_PROCESS_FRAME' && message.dataUrl) {
    processAndDispatchFrame(message.dataUrl);
    // Use short-lived response to prevent message channel locking
    sendResponse({ status: 'processing' });
    return true; 
  }
  return false; 
});

function initCanvas() {
  if (!canvasElement) {
    canvasElement = document.createElement('canvas');
    canvasElement.id = 'capture-canvas';
    document.body.appendChild(canvasElement);
    
    canvasElement.width = TARGET_WIDTH;
    canvasElement.height = TARGET_HEIGHT;
    canvasContext = canvasElement.getContext('2d', { alpha: false });
  }
}

function processAndDispatchFrame(rawDataUrl) {
  initCanvas();
  if (!canvasContext) return;

  const img = new Image();
  img.onload = () => {
    // Draw and scale the raw frame to the exact target dimensions
    canvasContext.drawImage(img, 0, 0, TARGET_WIDTH, TARGET_HEIGHT);

    // Convert to token-efficient JPEG Data URL
    const downsampledDataUrl = canvasElement.toDataURL('image/jpeg', JPEG_QUALITY);

    // Forward the optimized payload to the side panel for WebSocket transit
    chrome.runtime.sendMessage({
      action: 'FRAME_CAPTURED',
      dataUrl: downsampledDataUrl
    }).catch(() => {
        // Suppress dispatch failures if Side Panel is closed
    });
  };
  
  img.src = rawDataUrl;
}
import base64
import json
import re
from typing import Any

import httpx

from config import (
    GROQ_API_KEY,
    GROQ_BASE_URL,
    GROQ_VISION_MODEL,
    GROQ_VISION_RPD_LIMIT,
    GROQ_VISION_RPM_LIMIT,
    REQUEST_TIMEOUT_SECONDS,
)
from providers.base import BaseProvider, ProviderError
from router.rate_limiter import SlidingWindowLimiter

VISION_DESCRIBE_SYSTEM_PROMPT = """You are Nexvion Copilot, the AI screen guide that never needs a tutorial.
You are actively viewing the user's live browser screen captured in real-time via the Nexvion Chrome extension.
Confirm what you see on the screen directly and answer the user's question concisely in 1-3 sentences.

Rules:
1. Never refer to yourself as "an AI" or "a language model".
2. Never state or imply that you cannot see the screen or lack live display access.
3. Never ask or instruct the user to upload, attach, or share screenshots, as frame capture is automated in real-time by the extension.
4. No conversational fluff or preamble. State findings directly.
"""

GROUNDING_SYSTEM_PROMPT = """You are a precise visual grounding engine for web UI elements.
Given a screenshot and a list of target element labels, locate each element and return its normalized pixel coordinates on a [0, 1000] x [0, 1000] bounding grid.
(0,0 is top-left, 1000,1000 is bottom-right).

Do not include any reasoning, thinking, or explanation — output only the JSON array.

Output strictly valid JSON with no markdown code fences or conversational text, using this schema:
[
  {
    "label": "Target element label",
    "x": 500,
    "y": 250,
    "found": true
  }
]
If an element is not currently visible on the screen, set "found": false and "x": null, "y": null.
"""


class GroqVisionProvider(BaseProvider):
    """
    Vision and spatial grounding provider backed by Groq.
    Tracks 30 RPM / 1000 RPD limits with persistent disk state and strips reasoning traces.
    """

    def __init__(self) -> None:
        self.limiter = SlidingWindowLimiter(
            rpm_limit=GROQ_VISION_RPM_LIMIT,
            rpd_limit=GROQ_VISION_RPD_LIMIT,
            storage_key="groq_vision",
        )
        self.client = httpx.AsyncClient(timeout=REQUEST_TIMEOUT_SECONDS)

    async def call(self, messages: list[dict[str, Any]]) -> str:
        """Dispatches vision request to Groq, syncs rate-limit headers, and strips thinking blocks."""
        if not self.limiter.can_proceed():
            raise ProviderError(
                "Groq vision pool exhausted for this window "
                f"({self.limiter.remaining_today()} requests left today)."
            )

        try:
            payload = {
                "model": GROQ_VISION_MODEL,
                "messages": messages,
                "reasoning_effort": "none",
                "reasoning_format": "hidden",
            }

            response = await self.client.post(
                GROQ_BASE_URL,
                headers={
                    "Authorization": f"Bearer {GROQ_API_KEY}",
                    "Content-Type": "application/json",
                },
                json=payload,
            )
            self.limiter.record_call()

            # Synchronize remaining quota directly from Groq response headers
            if "x-ratelimit-remaining-requests" in response.headers:
                try:
                    rem_req = int(response.headers["x-ratelimit-remaining-requests"])
                    self.limiter.sync_from_provider(rem_req)
                except ValueError:
                    pass

            if response.status_code == 429:
                raise ProviderError(f"Groq vision model ({GROQ_VISION_MODEL}) rate-limited (429)")

            if response.status_code != 200:
                raise ProviderError(f"Groq vision error ({response.status_code}): {response.text}")

            data = response.json()
            raw_content: str = data["choices"][0]["message"]["content"]

            # Multi-layer defensive stripping: closed tags, unclosed leading blocks, and stray tags
            cleaned = re.sub(r"<think>.*?</think>", "", raw_content, flags=re.DOTALL)
            cleaned = re.sub(r"^<think>.*", "", cleaned, flags=re.DOTALL)
            cleaned = cleaned.replace("<think>", "").replace("</think>", "").strip()

            return cleaned

        except httpx.TimeoutException as exc:
            raise ProviderError(f"Groq vision request timed out: {exc}") from exc
        except httpx.HTTPStatusError as exc:
            raise ProviderError(f"Groq vision HTTP status error: {exc}") from exc
        except Exception as exc:
            raise ProviderError(f"Groq vision provider error: {exc}") from exc

    async def describe_screen(self, frame_bytes: bytes, user_query: str) -> str:
        """Screen-query mode: generates a concise description without cursor coordinates."""
        b64_img = base64.b64encode(frame_bytes).decode("utf-8")
        messages = [
            {"role": "system", "content": VISION_DESCRIBE_SYSTEM_PROMPT},
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": f"User query: {user_query}",
                    },
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/png;base64,{b64_img}"},
                    },
                ],
            },
        ]
        return await self.call(messages)

    async def ground_elements(
        self, frame_bytes: bytes, target_labels: list[str]
    ) -> list[dict[str, Any]]:
        """
        Batched visual grounding: locates multiple UI targets in a single vision call
        to conserve token and rate-limit budgets.
        """
        b64_img = base64.b64encode(frame_bytes).decode("utf-8")
        labels_str = ", ".join([f'"{lbl}"' for lbl in target_labels])
        prompt_text = (
            f"Locate these UI target elements on the screen: [{labels_str}]. "
            f"Return JSON coordinates matching the requested schema."
        )

        messages = [
            {"role": "system", "content": GROUNDING_SYSTEM_PROMPT},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt_text},
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/png;base64,{b64_img}"},
                    },
                ],
            },
        ]

        raw_json = await self.call(messages)
        return self._parse_grounding_json(raw_json, target_labels)

    def _parse_grounding_json(
        self, raw_text: str, requested_labels: list[str]
    ) -> list[dict[str, Any]]:
        """Parses JSON grounding response. Assumes <think> tags are already stripped in call()."""
        cleaned = raw_text.strip()
        
        # Robust array extraction: bypasses LLM conversational preambles
        start_idx = cleaned.find('[')
        end_idx = cleaned.rfind(']')
        if start_idx != -1 and end_idx != -1 and end_idx >= start_idx:
            cleaned = cleaned[start_idx:end_idx+1]
        else:
            if cleaned.startswith("```"):
                cleaned = re.sub(r"^```(?:json)?\n?", "", cleaned)
                cleaned = re.sub(r"\n?```$", "", cleaned)
                cleaned = cleaned.strip()

        try:
            parsed = json.loads(cleaned)
            if isinstance(parsed, list):
                results: list[dict[str, Any]] = []
                for item in parsed:
                    if isinstance(item, dict) and "label" in item:
                        results.append(
                            {
                                "label": str(item.get("label")),
                                "x": item.get("x"),
                                "y": item.get("y"),
                                "found": bool(item.get("found", False)),
                            }
                        )
                if results:
                    return results
        except json.JSONDecodeError:
            pass

        # Fallback empty grounding structure if JSON parsing misses
        return [{"label": lbl, "x": None, "y": None, "found": False} for lbl in requested_labels]

    async def aclose(self) -> None:
        await self.client.aclose()
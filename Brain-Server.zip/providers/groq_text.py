import httpx

from config import (
    GROQ_API_KEY,
    GROQ_BASE_URL,
    GROQ_TEXT_RPD_LIMIT,
    GROQ_TEXT_RPM_LIMIT,
    REQUEST_TIMEOUT_SECONDS,
    TEXT_MODEL_CHAIN,
)
from providers.base import BaseProvider, ProviderError
from router.rate_limiter import SlidingWindowLimiter


class GroqTextProvider(BaseProvider):
    """
    Conversational text pool. Separate quota entirely from OpenRouter's
    vision budget — this is what absorbs turns that don't need a fresh
    screenshot, keeping the vision pool reserved for calls that actually
    need it.
    """

    def __init__(self) -> None:
        self.limiter = SlidingWindowLimiter(GROQ_TEXT_RPM_LIMIT, GROQ_TEXT_RPD_LIMIT)
        self.client = httpx.AsyncClient(timeout=REQUEST_TIMEOUT_SECONDS)

    async def call(self, messages: list[dict]) -> str:
        if not self.limiter.can_proceed():
            raise ProviderError("Groq text pool exhausted for this window.")

        last_error: Exception | None = None
        for model in TEXT_MODEL_CHAIN:
            try:
                response = await self.client.post(
                    GROQ_BASE_URL,
                    headers={
                        "Authorization": f"Bearer {GROQ_API_KEY}",
                        "Content-Type": "application/json",
                    },
                    json={"model": model, "messages": messages},
                )
                self.limiter.record_call()

                if response.status_code == 429:
                    last_error = ProviderError(f"{model} rate-limited (429)")
                    continue

                response.raise_for_status()
                data = response.json()
                return data["choices"][0]["message"]["content"]

            except httpx.TimeoutException as exc:
                last_error = exc
                continue
            except httpx.HTTPStatusError as exc:
                last_error = exc
                continue

        raise ProviderError(f"All Groq text models exhausted or failing: {last_error}")

    async def aclose(self) -> None:
        await self.client.aclose()
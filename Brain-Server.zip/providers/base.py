from abc import ABC, abstractmethod
from typing import Any


class ProviderError(Exception):
    """Raised when every model in a provider's fallback chain fails."""


class BaseProvider(ABC):
    @abstractmethod
    async def call(self, messages: list[dict[str, Any]]) -> str:
        """Return the model's text response, or raise ProviderError."""
        raise NotImplementedError
import os
from dotenv import load_dotenv

load_dotenv()

GROQ_API_KEY = os.environ["GROQ_API_KEY"]
GROQ_BASE_URL = "https://api.groq.com/openai/v1/chat/completions"

# Vision Model Configuration (Groq)
GROQ_VISION_MODEL = "qwen/qwen3.6-27b"
GROQ_VISION_RPM_LIMIT = 30
GROQ_VISION_RPD_LIMIT = 1000
GROQ_VISION_TPM_LIMIT = 8000

# Text Model Configuration (Groq)
TEXT_MODEL_CHAIN = [
    "openai/gpt-oss-120b",
    "qwen/qwen3.6-27b",
]
GROQ_TEXT_RPM_LIMIT = 30
GROQ_TEXT_RPD_LIMIT = 1000

REQUEST_TIMEOUT_SECONDS = 4.0
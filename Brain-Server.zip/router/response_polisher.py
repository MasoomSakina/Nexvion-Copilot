from providers.groq_text import GroqTextProvider

POLISHER_SYSTEM_PROMPT = """You are a real-time UI guidance assistant.
Your job is to generate a concise, spoken-style instructional sentence directing the user to interact with the highlighted element on their screen.

Rules:
1. Maximum 1-2 short sentences.
2. Tone must be direct, imperative, and helpful.
3. No conversational filler (do NOT say "Sure!", "Okay,", "Here you go,", or "Certainly!").
4. State the element name and the immediate action clearly (e.g., "Click 'Compose' in the top-left menu to open a new message.").
5. Never use markdown formatting (no bolding, no asterisks).
"""


class ResponsePolisher:
    """
    Refines raw vision labels and spatial coordinates into polished,
    spoken-style guidance directives via a lightweight Groq text call.
    """

    def __init__(self, text_provider: GroqTextProvider | None = None) -> None:
        self.text_provider = text_provider or GroqTextProvider()

    async def polish_instruction(
        self,
        target_label: str,
        action_type: str,
        step_instruction: str,
        context: str = "",
    ) -> str:
        prompt = (
            f"Target Element: {target_label}\n"
            f"Action: {action_type}\n"
            f"Step Context: {step_instruction}\n"
        )
        if context:
            prompt += f"Task Context: {context}\n"

        messages = [
            {"role": "system", "content": POLISHER_SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ]

        try:
            response = await self.text_provider.call(messages)
            cleaned = response.strip().replace("*", "").replace("\n", " ")
            return cleaned if cleaned else step_instruction
        except Exception:
            # Fall back to base instruction if polisher call fails
            return step_instruction
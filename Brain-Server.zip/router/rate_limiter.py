import time
from collections import deque
from threading import Lock

from state.rate_limit_store import RateLimitStore


class SlidingWindowLimiter:
    """
    Tracks real call timestamps with persistent disk backing to prevent
    quota bleed across server restarts and cold starts.
    """

    def __init__(
        self,
        rpm_limit: int,
        rpd_limit: int,
        storage_key: str | None = None,
        store: RateLimitStore | None = None,
    ) -> None:
        self.rpm_limit = rpm_limit
        self.rpd_limit = rpd_limit
        self.storage_key = storage_key
        self.store = store or (RateLimitStore() if storage_key else None)
        self._minute_window: deque[float] = deque()
        self._day_window: deque[float] = deque()
        self._lock = Lock()

        if self.store and self.storage_key:
            persisted_ts = self.store.load_timestamps(self.storage_key)
            now = time.time()
            for ts in sorted(persisted_ts):
                if now - ts <= 86400:
                    self._day_window.append(ts)
                if now - ts <= 60:
                    self._minute_window.append(ts)

    def _prune(self, now: float) -> None:
        while self._minute_window and now - self._minute_window[0] > 60:
            self._minute_window.popleft()
        while self._day_window and now - self._day_window[0] > 86400:
            self._day_window.popleft()

    def can_proceed(self) -> bool:
        now = time.time()
        with self._lock:
            self._prune(now)
            return (
                len(self._minute_window) < self.rpm_limit
                and len(self._day_window) < self.rpd_limit
            )

    def record_call(self) -> None:
        now = time.time()
        with self._lock:
            self._minute_window.append(now)
            self._day_window.append(now)
            self._prune(now)
            if self.store and self.storage_key:
                self.store.save_timestamps(self.storage_key, list(self._day_window))

    def remaining_today(self) -> int:
        now = time.time()
        with self._lock:
            self._prune(now)
            return max(0, self.rpd_limit - len(self._day_window))

    def sync_from_provider(self, remaining_requests: int) -> None:
        """
        Syncs local state when the provider returns authoritative remaining
        quota in response headers.
        """
        now = time.time()
        with self._lock:
            self._prune(now)
            inferred_used = max(0, self.rpd_limit - remaining_requests)
            if inferred_used > len(self._day_window):
                diff = inferred_used - len(self._day_window)
                for _ in range(diff):
                    self._day_window.append(now)
                if self.store and self.storage_key:
                    self.store.save_timestamps(self.storage_key, list(self._day_window))
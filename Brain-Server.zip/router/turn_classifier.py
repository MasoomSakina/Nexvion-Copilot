import re

PREFIX_STRIP_REGEX = re.compile(
    r"^(nexvion\s*copilot|nexvion|copilot|hey|hi|hello|please|assistant)[,\s:]*",
    re.IGNORECASE,
)

SCREEN_QUERY_PATTERNS = [
    r"\bcan you see (my|the) screen\b",
    r"\bwhat('s| is) on (my|the) screen\b",
    r"\bwhat (do you see|am i looking at)\b",
    r"\bwhat is this (page|tab|site|screen|view)\b",
    r"\bdescribe (my|the|this) (screen|page|tab)\b",
    r"\blook at (my|the|this) screen\b",
    r"\bwhat does this page show\b",
]

NEGATIVE_PATTERNS = [
    r"\b(no|nope|don't|do not|cancel|nevermind|stop|not now|skip|negative)\b"
]

CONSENT_PATTERNS = [
    r"\b(yes|yeah|yep|yup|sure|ok|okay|please|go ahead|start|proceed|let's do it|guide me|do it|y)\b",
    r"\b(yes please|sure thing|go for it|sounds good|start guidance|provide guidance)\b",
    r"\b(step[-\s]?by[-\s]?step|on[-\s]?screen(\sguidance)?|guide\s*me|walk\s*me\s*through|show\s*me)\b",
]

NAV_INTENT_PATTERNS = [
    r"\bhow (do|can) i\b",
    r"\bhow to\b",
    r"\bwhere (is|are|can i find)\b",
    r"\bguide me (through|to|on)\b",
    r"\bhelp me (find|navigate|set up|configure|do|reach)\b",
    r"\bshow me (how|where)\b",
    r"\bsteps to\b",
    r"\bwalk me through\b",
    r"\bhow do you\b",
]


class TurnClassifier:
    """
    Zero-cost, in-process rule-based classifier using regex and keyword matching.
    Guarantees 0 API calls spent determining user intent or guidance consent.
    """

    def __init__(self) -> None:
        self.screen_regexes = [re.compile(p, re.IGNORECASE) for p in SCREEN_QUERY_PATTERNS]
        self.negative_regexes = [re.compile(p, re.IGNORECASE) for p in NEGATIVE_PATTERNS]
        self.consent_regexes = [re.compile(p, re.IGNORECASE) for p in CONSENT_PATTERNS]
        self.nav_regexes = [re.compile(p, re.IGNORECASE) for p in NAV_INTENT_PATTERNS]

    def classify(self, user_text: str, session_mode: str = "chat") -> str:
        """
        Classifies turn into 'CONSENT_YES', 'SCREEN_QUERY', or 'PURE_TEXT'.
        'CONSENT_YES' is strictly gated behind session_mode == 'awaiting_consent'.
        """
        raw_cleaned = user_text.strip().lower()
        stripped = PREFIX_STRIP_REGEX.sub("", raw_cleaned).strip()
        eval_text = stripped if stripped else raw_cleaned

        if session_mode == "awaiting_consent":
            # Check for explicit rejections
            for rx in self.negative_regexes:
                if rx.search(eval_text) or rx.search(raw_cleaned):
                    return "PURE_TEXT"

            # Check for consent affirmations or guidance keywords
            for rx in self.consent_regexes:
                if rx.search(eval_text) or rx.search(raw_cleaned):
                    return "CONSENT_YES"

        for rx in self.screen_regexes:
            if rx.search(eval_text) or rx.search(raw_cleaned):
                return "SCREEN_QUERY"

        return "PURE_TEXT"

    def has_nav_intent(self, user_text: str) -> bool:
        """
        Detects navigational/how-to intent to trigger deterministic
        guidance offers without delegating decision to an LLM.
        """
        raw_cleaned = user_text.strip().lower()
        stripped = PREFIX_STRIP_REGEX.sub("", raw_cleaned).strip()
        eval_text = stripped if stripped else raw_cleaned

        for rx in self.nav_regexes:
            if rx.search(eval_text) or rx.search(raw_cleaned):
                return True
        return False
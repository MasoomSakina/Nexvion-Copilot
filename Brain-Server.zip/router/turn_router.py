from typing import Any

from providers.base import ProviderError
from providers.groq_text import GroqTextProvider
from providers.groq_vision import GroqVisionProvider
from router.guide_planner import GuidePlanner
from router.response_polisher import ResponsePolisher
from router.turn_classifier import TurnClassifier
from state.session_state import SessionState

CHAT_SYSTEM_PROMPT = (
    "You are Nexvion Copilot, the AI screen guide that never needs a tutorial. "
    "You operate directly inside the user's browser via the Nexvion Chrome extension with live visual access to the active tab. "
    "You provide real-time visual assistance and guide users on-screen using a smart Ghost Cursor. "
    "Formatting and behavioral rules: "
    "1. When providing navigation or action instructions, format the output as clean, numbered steps with one step per line. "
    "2. Bold key UI elements, buttons, and tab names using markdown (e.g. **Compose**, **Send**). "
    "3. Never include assistant signatures, sign-offs, or self-names at the end of answers (e.g. do not end with 'Nexvion Copilot.'). "
    "4. Never refer to yourself as 'an AI', 'a language model', or a generic assistant. Always identify as Nexvion Copilot. "
    "5. Never state or imply that you lack live display access or request manual file/screenshot uploads. "
    "6. Never use conversational filler ('Certainly!', 'Here are the steps', 'I would be happy to help'). Jump straight into the direct instructions."
)

FALLBACK_EXHAUSTION_MESSAGE = (
    "I am currently experiencing high demand on the visual guidance engine. "
    "I have paused on-screen tracking, but I can continue guiding you via text right here."
)


class TurnRouter:
    """
    Central orchestration engine. Implements 4-branch routing, batched
    visual grounding, and graceful failure degradation to protect quotas.
    """

    def __init__(self) -> None:
        self.text_provider = GroqTextProvider()
        self.vision_provider = GroqVisionProvider()
        self.classifier = TurnClassifier()
        self.planner = GuidePlanner(self.text_provider)
        self.polisher = ResponsePolisher(self.text_provider)

    async def handle_turn(
        self,
        session: SessionState,
        user_text: str,
        frame_bytes: bytes | None = None,
    ) -> dict[str, Any]:
        """Processes an incoming text message through the zero-cost classified state machine."""
        session.record_turn("user", user_text)
        intent = self.classifier.classify(user_text, session_mode=session.mode)

        try:
            if intent == "CONSENT_YES":
                return await self._handle_consent_yes(session, user_text, frame_bytes)
            elif intent == "SCREEN_QUERY":
                return await self._handle_screen_query(session, user_text, frame_bytes)
            else:
                return await self._handle_pure_text(session, user_text)

        except Exception as exc:
            return await self._handle_exhaustion_fallback(session, str(exc))

    async def handle_step_advance(
        self,
        session: SessionState,
        frame_bytes: bytes | None = None,
    ) -> dict[str, Any]:
        """
        Handles client-side step completion signals with 0 LLM classification overhead.
        Advances the cursor silently, pushing the instruction to the screen instead of chat.
        """
        if session.mode != "guiding" or not session.guide_plan:
            return {
                "reply": "No active guidance session.",
                "cursor": None,
                "mode": session.mode,
                "completed": True,
            }

        session.current_step_index += 1

        if session.current_step_index >= len(session.guide_plan):
            completion_msg = "Task complete! You've finished all the steps."
            session.record_turn("assistant", completion_msg)
            session.reset_guidance()
            return {
                "reply": completion_msg,
                "cursor": None,
                "mode": "chat",
                "completed": True,
                "step_index": None,
                "total_steps": None,
            }

        current_step = session.guide_plan[session.current_step_index]
        target_label = current_step["target_label"]
        target_coord = self._find_target_in_cache(session, target_label)

        if (target_coord is None or (frame_bytes and session.frame_changed(frame_bytes))) and frame_bytes:
            try:
                remaining_labels = [
                    s["target_label"] for s in session.guide_plan[session.current_step_index :]
                ]
                new_targets = await self.vision_provider.ground_elements(frame_bytes, remaining_labels)
                session.cached_layout_targets = new_targets
                target_coord = self._find_target_in_cache(session, target_label)
            except Exception:
                pass

        polished_instruction = await self.polisher.polish_instruction(
            target_label=target_label,
            action_type=current_step.get("action_type", "click"),
            step_instruction=current_step.get("instruction", ""),
        )
        
        # Inject the polished instruction directly into the cursor payload
        if target_coord:
            target_coord["label"] = polished_instruction

        return {
            "reply": None,  # SILENT IN CHAT
            "cursor": target_coord,
            "mode": "guiding",
            "completed": False,
            "step_index": session.current_step_index,
            "total_steps": len(session.guide_plan),
        }

    async def _handle_consent_yes(
        self,
        session: SessionState,
        user_text: str,
        frame_bytes: bytes | None,
    ) -> dict[str, Any]:
        """Converts prior answer into structured steps, grounds visually, and initiates silent UI flow."""
        prior_context = session.last_text_answer or user_text
        plan = await self.planner.create_plan(user_goal=user_text, prior_answer=prior_context)

        session.mode = "guiding"
        session.guide_plan = plan
        session.current_step_index = 0
        session.cached_layout_targets = []

        target_labels = [step["target_label"] for step in plan]

        if frame_bytes:
            session.cached_layout_targets = await self.vision_provider.ground_elements(
                frame_bytes, target_labels
            )

        step_0 = plan[0]
        target_coord = self._find_target_in_cache(session, step_0["target_label"])

        instruction = await self.polisher.polish_instruction(
            target_label=step_0["target_label"],
            action_type=step_0.get("action_type", "click"),
            step_instruction=step_0.get("instruction", ""),
        )
        
        if target_coord:
            target_coord["label"] = instruction

        # Fixed, generic chat reply. The screen cursor will display the actual instruction.
        chat_reply = "Please follow the step-by-step on-screen instructions."
        session.record_turn("assistant", chat_reply)

        return {
            "reply": chat_reply,
            "cursor": target_coord,
            "mode": "guiding",
            "completed": False,
            "step_index": 0,
            "total_steps": len(plan),
        }

    async def _handle_screen_query(
        self,
        session: SessionState,
        user_text: str,
        frame_bytes: bytes | None,
    ) -> dict[str, Any]:
        session.mode = "chat"
        if not frame_bytes:
            reply = "I am actively monitoring your tab. What would you like me to inspect or guide you through?"
            session.record_turn("assistant", reply)
            return {"reply": reply, "cursor": None, "mode": "chat"}

        description = await self.vision_provider.describe_screen(frame_bytes, user_text)
        session.record_turn("assistant", description)
        return {"reply": description, "cursor": None, "mode": "chat"}

    async def _handle_pure_text(
        self,
        session: SessionState,
        user_text: str,
    ) -> dict[str, Any]:
        messages = [{"role": "system", "content": CHAT_SYSTEM_PROMPT}] + session.conversation_history[-10:]
        reply = await self.text_provider.call(messages)

        has_nav = self.classifier.has_nav_intent(user_text)
        if has_nav and not session.last_offered_guidance:
            session.last_offered_guidance = True
            session.last_text_answer = reply
            session.mode = "awaiting_consent"
            reply = f"{reply.strip()}\n\nWould you like step-by-step, on-screen guidance?"
        else:
            session.mode = "chat"

        session.record_turn("assistant", reply)
        return {"reply": reply, "cursor": None, "mode": session.mode}

    async def _handle_exhaustion_fallback(
        self,
        session: SessionState,
        error_context: str,
    ) -> dict[str, Any]:
        session.reset_guidance()
        fallback_prompt = (
            f"The user encountered an issue with screen guidance ({error_context}). "
            "Politely explain that you cannot view their screen at this moment, but can assist via chat."
        )
        try:
            messages = [
                {"role": "system", "content": CHAT_SYSTEM_PROMPT},
                {"role": "user", "content": fallback_prompt},
            ]
            reply = await self.text_provider.call(messages)
        except Exception:
            reply = FALLBACK_EXHAUSTION_MESSAGE

        session.record_turn("assistant", reply)
        return {"reply": reply, "cursor": None, "mode": "chat", "fallback": True}

    def _find_target_in_cache(
        self, session: SessionState, target_label: str
    ) -> dict[str, Any] | None:
        target_clean = target_label.strip().lower()
        for item in session.cached_layout_targets:
            if item.get("found") and item.get("label", "").strip().lower() == target_clean:
                if item.get("x") is not None and item.get("y") is not None:
                    return {"x": item["x"], "y": item["y"], "label": item["label"]}
        for item in session.cached_layout_targets:
            item_lbl = item.get("label", "").strip().lower()
            if item.get("found") and (target_clean in item_lbl or item_lbl in target_clean):
                if item.get("x") is not None and item.get("y") is not None:
                    return {"x": item["x"], "y": item["y"], "label": item["label"]}
        for item in session.cached_layout_targets:
            if item.get("found") and item.get("x") is not None and item.get("y") is not None:
                return {"x": item["x"], "y": item["y"], "label": item["label"]}
        return None

    def _build_text_messages(self, session: SessionState) -> list[dict[str, Any]]:
        return [{"role": "system", "content": CHAT_SYSTEM_PROMPT}] + session.conversation_history[-10:]

    async def shutdown(self) -> None:
        await self.vision_provider.aclose()
        await self.text_provider.aclose()
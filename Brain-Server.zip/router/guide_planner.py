import json
import re
from typing import Any

from providers.groq_text import GroqTextProvider

PLANNER_SYSTEM_PROMPT = """You are a precise task decomposition engine.
Convert the provided solution/explanation into a clean, ordered list of discrete, actionable steps that a user must perform on their screen.

Output strictly valid JSON with no conversational preamble or markdown code fences, using this schema:
[
  {
    "step_index": 0,
    "target_label": "Name or text of the button/field to interact with",
    "action_type": "click | type | select | navigate",
    "instruction": "Short imperative instruction (e.g. Click 'Compose' to start a new email)"
  }
]
Keep the plan between 2 and 6 concrete steps. Ensure every step has an identifiable on-screen target_label.
"""


class GuidePlanner:
    """
    Transforms conversational explanations into structured, machine-actionable
    step sequences via a single Groq text call.
    """

    def __init__(self, text_provider: GroqTextProvider | None = None) -> None:
        self.text_provider = text_provider or GroqTextProvider()

    async def create_plan(self, user_goal: str, prior_answer: str) -> list[dict[str, Any]]:
        messages = [
            {"role": "system", "content": PLANNER_SYSTEM_PROMPT},
            {
                "role": "user",
                "content": f"User Goal: {user_goal}\n\nSolution to Decompose:\n{prior_answer}",
            },
        ]

        raw_response = await self.text_provider.call(messages)
        return self._parse_plan_json(raw_response)

    def _parse_plan_json(self, raw_text: str) -> list[dict[str, Any]]:
        cleaned = raw_text.strip()
        
        # Robust array extraction: bypasses LLM conversational preambles
        start_idx = cleaned.find('[')
        end_idx = cleaned.rfind(']')
        if start_idx != -1 and end_idx != -1 and end_idx >= start_idx:
            cleaned = cleaned[start_idx:end_idx+1]
        else:
            # Fallback markdown removal
            if cleaned.startswith("```"):
                cleaned = re.sub(r"^```(?:json)?\n?", "", cleaned)
                cleaned = re.sub(r"\n?```$", "", cleaned)
                cleaned = cleaned.strip()

        try:
            parsed = json.loads(cleaned)
            if isinstance(parsed, list) and len(parsed) > 0:
                validated_steps: list[dict[str, Any]] = []
                for idx, step in enumerate(parsed):
                    if isinstance(step, dict):
                        validated_steps.append(
                            {
                                "step_index": idx,
                                "target_label": str(step.get("target_label", f"Step {idx + 1}")),
                                "action_type": str(step.get("action_type", "click")),
                                "instruction": str(
                                    step.get("instruction", "Follow on-screen guidance.")
                                ),
                            }
                        )
                if validated_steps:
                    return validated_steps
        except json.JSONDecodeError:
            pass

        # Fallback single-step recovery if JSON parsing fails
        return [
            {
                "step_index": 0,
                "target_label": "Next Step",
                "action_type": "click",
                "instruction": "Follow the highlighted element on your screen.",
            }
        ]
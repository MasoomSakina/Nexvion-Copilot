import base64
from typing import Any

from fastapi import FastAPI, WebSocket, WebSocketDisconnect

from router.turn_router import TurnRouter
from state.session_state import SessionState

app = FastAPI(title="Live AI Screen Guide - Brain Server")
turn_router = TurnRouter()
active_sessions: dict[str, SessionState] = {}


@app.websocket("/ws/{session_id}")
async def websocket_endpoint(websocket: WebSocket, session_id: str) -> None:
    await websocket.accept()
    session = active_sessions.setdefault(session_id, SessionState())

    try:
        while True:
            payload: dict[str, Any] = await websocket.receive_json()
            msg_type = payload.get("type", "turn")
            frame_b64: str | None = payload.get("frame_b64")

            frame_bytes: bytes | None = None
            if frame_b64:
                try:
                    frame_bytes = base64.b64decode(frame_b64)
                except Exception:
                    frame_bytes = None

            # Handle client-side step completion signal (zero LLM calls)
            if msg_type == "step_complete":
                response = await turn_router.handle_step_advance(session, frame_bytes)
                await websocket.send_json(
                    {
                        "reply": response.get("reply"),
                        "cursor": response.get("cursor"),
                        "mode": response.get("mode", session.mode),
                        "completed": response.get("completed", False),
                        "step_index": response.get("step_index"),
                        "total_steps": response.get("total_steps"),
                        "error": None,
                    }
                )
                continue

            # Standard user turn
            user_text: str = payload.get("text", "")
            response = await turn_router.handle_turn(session, user_text, frame_bytes)

            await websocket.send_json(
                {
                    "reply": response.get("reply"),
                    "cursor": response.get("cursor"),
                    "mode": response.get("mode", session.mode),
                    "completed": response.get("completed", False),
                    "step_index": response.get("step_index"),
                    "total_steps": response.get("total_steps"),
                    "fallback": response.get("fallback", False),
                    "error": None,
                }
            )

    except WebSocketDisconnect:
        active_sessions.pop(session_id, None)
    except Exception as exc:
        try:
            await websocket.send_json(
                {
                    "reply": "Session connection was interrupted. Please send a message to continue.",
                    "cursor": None,
                    "mode": "chat",
                    "error": str(exc),
                }
            )
        except Exception:
            pass
        active_sessions.pop(session_id, None)


@app.on_event("shutdown")
async def shutdown_event() -> None:
    await turn_router.shutdown()
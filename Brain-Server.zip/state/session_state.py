import hashlib
from dataclasses import dataclass, field
from typing import Any


@dataclass
class SessionState:
    """
    Tracks state per browser session/tab. Manages mode state machine,
    active guidance step plans, frame hashes for layout changes, and
    conversation context.
    """

    mode: str = "chat"  # "chat" | "awaiting_consent" | "guiding"
    conversation_history: list[dict[str, Any]] = field(default_factory=list)
    last_text_answer: str | None = None
    last_offered_guidance: bool = False

    # Guide mode tracking
    guide_plan: list[dict[str, Any]] = field(default_factory=list)
    current_step_index: int = 0
    cached_layout_targets: list[dict[str, Any]] = field(default_factory=list)

    # Vision cache & telemetry
    last_frame_hash: str | None = None
    last_vision_call_ts: float = 0.0

    def frame_changed(self, frame_bytes: bytes) -> bool:
        """Returns True if the frame hash differs from the prior frame."""
        new_hash = hashlib.sha256(frame_bytes).hexdigest()
        changed = new_hash != self.last_frame_hash
        self.last_frame_hash = new_hash
        return changed

    def record_turn(self, role: str, content: str) -> None:
        """Appends a turn to conversation history, bounded to the last 20 entries."""
        self.conversation_history.append({"role": role, "content": content})
        if len(self.conversation_history) > 20:
            self.conversation_history = self.conversation_history[-20:]

    def reset_guidance(self) -> None:
        """Resets active guidance state back to standard chat mode."""
        self.mode = "chat"
        self.guide_plan = []
        self.current_step_index = 0
        self.cached_layout_targets = []
        self.last_offered_guidance = False
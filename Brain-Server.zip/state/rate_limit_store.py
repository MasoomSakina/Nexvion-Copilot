import json
import os
import tempfile
from pathlib import Path


class RateLimitStore:
    """
    Handles atomic flat-file persistence for sliding window timestamps.
    Prevents quota resets and 429 exhaustion across server restarts.
    """

    def __init__(self, storage_path: str = "rate_limit_state.json") -> None:
        self.storage_path = Path(storage_path)

    def load_timestamps(self, key: str) -> list[float]:
        """Load call timestamps for a given key. Returns empty list if missing or corrupted."""
        if not self.storage_path.exists():
            return []

        try:
            with open(self.storage_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict) and key in data and isinstance(data[key], list):
                    return [float(ts) for ts in data[key] if isinstance(ts, (int, float))]
                return []
        except (json.JSONDecodeError, OSError, ValueError):
            return []

    def save_timestamps(self, key: str, timestamps: list[float]) -> None:
        """Atomically persist timestamp lists to disk using a temporary file swap."""
        current_data: dict[str, list[float]] = {}
        if self.storage_path.exists():
            try:
                with open(self.storage_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        current_data = data
            except (json.JSONDecodeError, OSError):
                current_data = {}

        current_data[key] = timestamps

        target_dir = self.storage_path.parent
        target_dir.mkdir(parents=True, exist_ok=True)

        try:
            with tempfile.NamedTemporaryFile(
                "w", dir=target_dir, delete=False, encoding="utf-8"
            ) as tmp_file:
                json.dump(current_data, tmp_file, indent=2)
                temp_name = tmp_file.name

            os.replace(temp_name, self.storage_path)
        except OSError:
            if "temp_name" in locals() and os.path.exists(temp_name):
                try:
                    os.remove(temp_name)
                except OSError:
                    pass